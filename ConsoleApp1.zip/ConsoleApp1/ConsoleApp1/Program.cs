﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            CSV file = new CSV("tenants.csv");

            for (; ; )
            {
                Console.WriteLine("Select An Option: \n a --> Remove tenant" +
                    "\n b --> Add tenant\n c --> Edit existing tenant\n d --> Show Current Tenants\n e --> Show Vacant Rooms\n exit --> exit");

                string userInput = Console.ReadLine();
                if (userInput.ToLower() == "a") //Remove Tenant
                {
                    file.ListCurrentTenants();
                    Console.Write("Select the apartment number to remove (type cancel to cancel)--> ");
                    while (file.RemoveTenant() == false) ;
                }
                else if (userInput.ToLower() == "b") //Add Tenant
                {
                    file.ListVacantRooms();
                    Console.Write("Select the apartment number to add (type cancel to cancel)--> ");
                    while (file.AddTenant() == false);

                }
                else if (userInput.ToLower() == "c") //Edit existing Tenant
                {
                    file.ListCurrentTenants();
                    Console.Write("Select the apartment number to edit (type cancel to cancel)--> ");
                    while (file.EditTenant() == false) ;
                }
                else if (userInput.ToLower() == "d") //Show Current Tenants
                {
                    file.ListCurrentTenants();
                }
                else if (userInput.ToLower() == "e") //Show Vacant Rooms
                {
                    file.ListVacantRooms();
                }
                else if (userInput.ToLower() == "exit") //EXIT
                {
                    Console.WriteLine("Exiting...");
                    Environment.Exit(0);
                }
                else
                {
                    CSV.DisplayError("Invalid Input\n");
                }
            }
            


        }
    }
}
