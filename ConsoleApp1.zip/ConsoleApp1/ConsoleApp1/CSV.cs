﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Tenant
    {
        public string firstName, lastName;
        private float rent;
        public float Rent { get { return rent; }
            set
            {
                if (value < rent)
                {
                    CSV.DisplayError("Rent Cannot be reduced for a Tenant!\n");
                    throw new InvalidOperationException();
                }
                else
                {
                    rent = value;
                }
            } }

        public Tenant(string firstName, string lastName, float rent)
        {
            this.firstName = firstName;
            this.lastName = lastName;
            this.rent = rent;
        }
    }
    class Room
    {
        private string roomNumber;
        public string RoomNumber { get { return roomNumber; } }
        private Tenant tenant;
        public Tenant Tenant { get { return tenant; } }

        public Room(string roomNumber, Tenant tenant) //initalize room with a tenant
        {
            this.roomNumber = roomNumber;
            this.tenant = tenant;
        }
        public Room(string roomNumber) //initialize room with no tenant
        {
            this.roomNumber = roomNumber;
            this.tenant = null;
        }

        public void WriteRoomInConsole()
        {
            if (Tenant is null)
            {
                Console.Write("Room ");// + roomNumber + " is empty!");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write(roomNumber);
                Console.ForegroundColor = CSV.defaultConsoleColor;
                Console.Write(" is empty!\n");
            }
            else
            {
                Console.Write(Tenant.firstName + " " + Tenant.lastName + ", Apartment "); //
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write(roomNumber);
                Console.ForegroundColor = CSV.defaultConsoleColor;
                Console.Write(" Rent:" + Tenant.Rent + "\n");
            }
        }


        public string ReturnRoomFormatted() //return current room class in a format readable by database
        {
            if (Tenant is null)
            {
                return ",," + RoomNumber + ",0";
            }
            else
            {
                return Tenant.firstName + "," + Tenant.lastName + "," + RoomNumber +"," +Tenant.Rent;
            }
        }

        public void RemoveTenant()
        {
            tenant = null;
        }


        public static Room FindRoom(List<Room> rooms, string roomNumber) //Find and return the room that has the specified roomnumber
        {
            foreach (Room room in rooms)
            {
                if (room.roomNumber == roomNumber)
                {
                    return room;
                }
            }
            return null;
        }

        public void AddTenant(string firstName, string lastName,float rent)
        {
            tenant = new Tenant(firstName, lastName, rent);
        }
    }



    class CSV //Database class
    {
        public static ConsoleColor defaultConsoleColor = Console.ForegroundColor;
        string path;
        List<Room> AllRooms = new List<Room>();


        public void UpdateFile() //Convert list of rooms into database format
        {
            string[] fileContents = new string[AllRooms.Count()];
            int i = 0;
            foreach (Room room in AllRooms)
            {
                fileContents[i++] = room.ReturnRoomFormatted();
            }

            File.WriteAllLines(path, fileContents);
        }

        public CSV(string path) //Initialize database, exit if errors found
        {
            this.path = path;

            string[] fileContents;
            try
            {
                fileContents = File.ReadAllLines(this.path);
            }
            catch (Exception e)
            {
                for (; ; )
                {
                    DisplayError("FILE NOT FOUND, PLEASE MAKE SURE FILE IS IN PROPER DESTINATION");
                    Console.ReadLine();
                    Environment.Exit(0);
                }
            }
            try
            {
                foreach (string line in fileContents)
                {
                    string[] lineContents = line.Split(',');

                    if (string.IsNullOrEmpty(lineContents[0]) && string.IsNullOrEmpty(lineContents[1]))
                    {
                        AllRooms.Add(new Room(lineContents[2]));
                    }
                    else
                    {
                        AllRooms.Add(new Room(lineContents[2], new Tenant(lineContents[0], lineContents[1], float.Parse(lineContents[3]))));
                    }
                }
            }
            catch (Exception e)
            {
                for(; ;)
                {
                    DisplayError("FILE CORRUPTED, CANNOT BE READ");
                    Console.ReadLine();
                    Environment.Exit(0);
                }
            }
        }

        public List<string> ListCurrentTenants()
        {
            
            List<string> currentTenants = new List<string>();
            Console.WriteLine("Current Tenants -->");

            foreach (Room room in AllRooms)
            {
                if (!(room.Tenant is null))
                {
                    room.WriteRoomInConsole();
                }
            }
            return currentTenants;
        }

        public void ListVacantRooms()
        {
            List<string> currentTenants = new List<string>();
            Console.WriteLine("Current Vacants -->");

            foreach (Room room in AllRooms)
            {
                if (room.Tenant is null)
                {
                    room.WriteRoomInConsole();
                }
            }
        }

        public bool RemoveTenant() //Returns true if removing tenant was successful (or user cancels)
        {
            string roomNumber = Console.ReadLine();
            if (roomNumber.ToLower() == "cancel")
            {
                return true;
            }

            Room occupiedRoom = Room.FindRoom(AllRooms, roomNumber);

            if (occupiedRoom is null) //room doesnt exist
            {
                DisplayError("Room number doesnt exist, Try again --> ");
                return false;
            }
            else
            {
                if (occupiedRoom.Tenant is null) //tenant doesnt exist
                {
                    DisplayError("Tenant doesnt exist, Try again --> ");
                    return false;
                }
                else //tenant does exist
                {
                    occupiedRoom.RemoveTenant();
                    UpdateFile();
                    return true;
                }
            }
        }

        public bool AddTenant() //Returns true if adding tenant was successful (or user cancels)
        {
            
            string roomNumber = Console.ReadLine();
            if (roomNumber.ToLower() == "cancel")
            {
                return true;
            }


            Room vacantRoom = Room.FindRoom(AllRooms, roomNumber);

            if (vacantRoom is null) //room doesnt exist
            {
                DisplayError("Room number doesnt exist, Try again --> ");
                return false;
            }
            else
            {
                if (vacantRoom.Tenant is null)//tenant doesnt exist
                {
                    string firstName, lastName;
                    float rent;
                    Console.Write("First Name (type cancel to cancel)--> ");
                    for (; ; )
                    {
                        firstName = Console.ReadLine();
                        if (firstName.ToLower() == "cancel")
                        {
                            return true;
                        }
                        else if (!string.IsNullOrWhiteSpace(firstName))
                        {
                            break;
                        }
                        else
                        {
                            DisplayError("Please put a valid name --> ");
                        }
                    }
                    Console.Write("Last Name (type cancel to cancel)--> ");
                    for (; ; )
                    {
                        lastName = Console.ReadLine();
                        if (lastName.ToLower() == "cancel")
                        {
                            return true;
                        }
                        else if (!string.IsNullOrWhiteSpace(lastName))
                        {
                            break;
                        }
                        else
                        {
                            DisplayError("Please put a valid name --> ");
                        }
                    }
                    Console.Write("Rent (type cancel to cancel)--> ");
                    for (; ; )
                    {
                        string input = Console.ReadLine();
                        if (input.ToLower() == "cancel")
                        {
                            return true;
                        }
                        try
                        {
                            rent = float.Parse(input);
                            if (rent < 0)
                            {
                                throw new InvalidOperationException();
                            }
                        }
                        catch (InvalidOperationException e)
                        {
                            DisplayError("Rent cannot be negative --> ");
                            continue;
                        }
                        catch (Exception e)
                        {
                            DisplayError("Please put a valid number --> ");
                            continue;
                        }
                        break;
                    }

                    vacantRoom.AddTenant(firstName,lastName,rent);
                    UpdateFile();
                    return true;
                }
                else //tenant does exist
                {
                    DisplayError("Apartment already occupied, Try again --> ");
                    return false;
                }
            }
        }

        public bool EditTenant()//Returns true if editing tenant was successful (or user cancels)
        {
            string roomNumber = Console.ReadLine();

            if (roomNumber.ToLower() == "cancel")
            {
                return true;
            }
            Room occupiedRoom = Room.FindRoom(AllRooms, roomNumber);

            if (occupiedRoom is null) //room doesnt exist
            {
                DisplayError("Room number doesnt exist, Try again --> ");
                return false;
            }
            else
            {
                if (occupiedRoom.Tenant is null) //tenant doesnt exist
                {
                    DisplayError("Tenant doesnt exist, Try again --> ");
                    return false;
                }
                else //tenant does exist
                {
                    string firstName = occupiedRoom.Tenant.firstName, lastName = occupiedRoom.Tenant.lastName;
                    float rent = occupiedRoom.Tenant.Rent;

                    for (; ; )
                    {
                        Console.WriteLine("Editing Tenant: " + firstName + " " + lastName + ", Rent: " + rent);
                        Console.WriteLine("Choose an Option to change-->");
                        Console.WriteLine("Select An Option: \n a --> first name\n b --> last name\n c --> rent amount\n type 'exit' To save and exit\n type 'cancel' to cancel all changes");
                        string userInput = Console.ReadLine();
                        if (userInput.ToLower() == "a")
                        {
                            Console.Write("First Name (type cancel to cancel)--> "); //edit firstname
                            for (; ; )
                            {
                                string firstNameUpdate = Console.ReadLine();
                                if (firstNameUpdate.ToLower() == "cancel")
                                {

                                    break;
                                }
                                else if (!string.IsNullOrWhiteSpace(firstNameUpdate))
                                {
                                    firstName = firstNameUpdate;
                                    break;
                                }
                                else
                                {
                                    DisplayError("Please put a valid name --> ");
                                }
                            }
                        }
                        else if (userInput.ToLower() == "b") //edit last name
                        {
                            Console.Write("Last Name (type cancel to cancel)--> ");
                            for (; ; )
                            {
                                string lastNameUpdate = Console.ReadLine();
                                if (lastNameUpdate.ToLower() == "cancel")
                                {

                                    break;
                                }
                                else if (!string.IsNullOrWhiteSpace(lastNameUpdate))
                                {
                                    lastName = lastNameUpdate;
                                    break;
                                }
                                else
                                {
                                    DisplayError("Please put a valid name --> ");
                                }
                            }
                        }
                        else if (userInput.ToLower() == "c") //Edit rent
                        {
                            Console.Write("Rent (type cancel to cancel)--> ");
                            for (; ; )
                            {
                                string input = Console.ReadLine();
                                if (input.ToLower() == "cancel")
                                {
                                    break;
                                }
                                try
                                {
                                    float tempRent = float.Parse(input);
                                    if (tempRent <= occupiedRoom.Tenant.Rent)
                                    {
                                        throw new InvalidOperationException();
                                    }
                                }
                                catch (InvalidOperationException e)
                                {
                                    DisplayError("Rent cannot be less than previous rent amount --> ");
                                    continue;
                                }
                                catch (Exception e)
                                {
                                    DisplayError("Please put a valid number --> ");
                                    continue;
                                }
                                rent = float.Parse(input);
                                break;
                            }
                        }
                        else if (userInput.ToLower() == "exit")
                        {
                            occupiedRoom.Tenant.firstName = firstName;
                            occupiedRoom.Tenant.lastName = lastName;
                            occupiedRoom.Tenant.Rent = rent;

                            UpdateFile();
                            return true;
                        }
                        else if (userInput.ToLower() == "cancel")
                        {
                            //UpdateFile();
                            return true;
                        }
                    }
                }
            }
        }


        public static void DisplayError(string error)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write(error);
            Console.ForegroundColor = defaultConsoleColor;
        }
        
    }
}
